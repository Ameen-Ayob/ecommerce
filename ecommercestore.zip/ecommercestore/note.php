<!DOCTYPE html>
    <html lang="en">
    <head>
        <?php include 'includes/links.php'?>
    </head>
    <body>
        <?php include 'nav-bar.php'?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="text-center mt-2">About Us – The Glam Jewels</h4>
                    <p>At The Glam Jewels, we believe that jewelry isn’t just an adornment—it’s an art form, a story, and an extension of your personality. Established in 2024, our online jewelry boutique is your destination for captivating designs that merge modern elegance with timeless charm.
                        We’re passionate about crafting collections that celebrate individuality, empower self-expression, and add a touch of magic to every moment. From delicate everyday staples to bold statement pieces, each item in our collection is meticulously curated to resonate with your unique style.
                        At The Glam Jewels, luxury meets accessibility. Our commitment is to deliver exceptional quality, unparalleled craftsmanship, and trend-forward designs—all from the comfort of your home. Every purchase with us is more than just a transaction; it begins a relationship built on trust, beauty, and shared love for the finer things.
                        Let us be a part of your journey, helping you create unforgettable memories, one jewel at a time. Because at The Glam Jewels, we don’t just sell jewelry—we craft stories that shine.
                    </p> 
                    <h4>Note:</h4>
                        •	We are only responsible for returns once it reaches our warehouse.
                  <br>  •	Please note returns are catered only if returned products are sent through courier services.
                  <br>  •	All successfully returned items can be exchanged for other articles or online store credit. In case a product is faulty or wrongly <br> delivered, The Glam Jewels will follow the policy of repair following replacement and finally store credit if the item cannot be repaired or replaced.
                  <br>  •	Timeline for Refund against a returned item: 14 days to 45 days.

                </div>
            </div>
        </div>



        <?php include 'footer.php'?>
        <?php include 'includes/script.php'?>
    </body>
</html>