<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include 'includes/links.php'?>
    </head>
    <body>
        <?php include 'nav-bar.php'?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="text-center mt-2">About Us – The Glam Jewels</h4>
                    <p>At The Glam Jewels, we believe that jewelry isn’t just an adornment—it’s an art form, a story, and an extension of your personality. Established in 2024, our online jewelry boutique is your destination for captivating designs that merge modern elegance with timeless charm.
                        We’re passionate about crafting collections that celebrate individuality, empower self-expression, and add a touch of magic to every moment. From delicate everyday staples to bold statement pieces, each item in our collection is meticulously curated to resonate with your unique style.
                        At The Glam Jewels, luxury meets accessibility. Our commitment is to deliver exceptional quality, unparalleled craftsmanship, and trend-forward designs—all from the comfort of your home. Every purchase with us is more than just a transaction; it begins a relationship built on trust, beauty, and shared love for the finer things.
                        Let us be a part of your journey, helping you create unforgettable memories, one jewel at a time. Because at The Glam Jewels, we don’t just sell jewelry—we craft stories that shine.
                    </p>
                    <h4>Shipping</h4>
                    <p> <b> 1)	Do you deliver worldwide & how long it takes?</b> <br>
                            Yes, we offer worldwide delivery through FedEx and DHL, with an estimated delivery time of 4-7 working days. <br>
                    <b>  2)	What are the shipping charges ?</b> <br>
                            Shipping charges depend on the delivery destination and will be calculated and added during checkout. For more information please visit our page Shipping-Detail 
                    </p>
                </div>
            </div>
        </div>



        <?php include 'footer.php'?>
        <?php include 'includes/script.php'?>
    </body>
</html>