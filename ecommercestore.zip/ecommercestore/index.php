<!DOCTYPE html>
<html lang="en">
<head>
    <?php include 'includes/links.php'; ?>
</head>
<body>
    <?php include 'nav-bar.php'; ?>
    <?php include 'banner.php'; ?>

    <div class="container">
        <div class="row">
        
        <?php
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = 12; 
        $offset = ($page - 1) * $limit;

        $user = "SELECT * FROM `product` LIMIT {$limit} OFFSET {$offset}";
        $exeUser = mysqli_query($conn, $user);
        
        while($exeUserResult = mysqli_fetch_assoc($exeUser)) {
            $productID = $exeUserResult['product_id'];
            $productTitle = $exeUserResult['product_title'];
            $productCode = $exeUserResult['product_code'];
            $productPrice = $exeUserResult['product_price'];
            $productImage = $exeUserResult['product_image'];
            ?>
        
        <div class="col-md-4 my-3 col-sm-3">
            <div class="card product-card" style="width: 18rem;">
                <img src="./Admin/<?php echo htmlspecialchars($productImage); ?>" class="card-img-top" alt="Product Image">
                <div class="card-body">
                <a href="product.php?id=<?php echo urlencode($productID); ?>&title=<?php echo urlencode($productTitle); ?>" class="text-decoration-none text-dark">
                    <h5 id="product-title-<?php echo $productID; ?>" class="card-title"><?php echo htmlspecialchars($productTitle); ?></h5>
                </a>
                <p id="product-code-<?php echo $productID; ?>" class="card-text">
                    <b>Article: </b> <?php echo htmlspecialchars($productCode); ?>
                </p>
                <p id="product-price-<?php echo $productID; ?>" class="card-text">
                    <b>Price: </b> PKR <?php echo htmlspecialchars($productPrice); ?>
                </p>
                <button class="btn btn-primary cart-icon" id="cartBtn"
                        data-id="<?php echo $productID; ?>">
                        <i class="fas fa-shopping-cart"></i> Add to Cart
                </button>

            </div>
            </div>
        </div>

        <?php
        }?>
        </div> 

        <?php
            // Pagination details
            $countQuery = "SELECT COUNT(*) AS total_product FROM product";
            $exeCountQuery = mysqli_query($conn, $countQuery);
            $countQueryRes = mysqli_fetch_array($exeCountQuery);
            $total_products = $countQueryRes['total_product'];
            $total_pages = ceil($total_products / $limit); // Round up to the next whole number
        ?>

        </div> <!-- End row for products -->

        <!-- Pagination -->
        <div class="row mt-4">
            <div class="col-12">
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <!-- Previous Page Link -->
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>&limit=<?php echo $limit; ?>" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <!-- Page Numbers -->
                            <?php 
                                $start_page = max(1, $page - 1); // Ensure starting page is at least 1
                                $end_page = min($total_pages, $page + 1); // Ensure ending page does not exceed total pages
                                
                                for ($i = $start_page; $i <= $end_page; $i++):
                            ?>
                                <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>&limit=<?php echo $limit; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>

                            <!-- Last page if needed -->
                            <?php if ($total_pages > 3 && $page < $total_pages - 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $total_pages; ?>&limit=<?php echo $limit; ?>"><?php echo $total_pages; ?></a>
                                </li>
                            <?php endif; ?>

                            <!-- Next Page Link -->
                            <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>&limit=<?php echo $limit; ?>" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <!-- Pagination and other content -->

    </div>

    <?php include 'footer.php'; ?>
    <?php include 'includes/script.php'; ?>

</body>
</html>
