<section class="top-bar stick">
    <div class="container-fluid p-0">
        <div class=" py-1 text text-light d-flex justify-content-center">
            <div class="col-md-6 text-center">
                <a class="text-decoration-none text-dark" href="contact.php"><i class="fa-solid fa-phone"></i> Contact </a>
                <a class="text-decoration-none text-dark b" href="about.php"><i class="fa-solid fa-circle-info"></i> About</a>
    
            </div>
            <div class="col-md-6 text-center"> 
                <?php if(isset($_SESSION['user'])){ ?>
                    <a class="text-decoration-none text-dark" href="logout.php"><i class="fa-solid fa-lock"></i> Log Out </a>
                    <a class="text-decoration-none text-dark b" href="cart.php"> <i class="fa-solid fa-bag-shopping me-1"></i>Shopping Bag </a>
                <?php }else{ ?>
                    <a class="text-decoration-none text-dark" href="login.php"><i class="fa-solid fa-lock"></i> Login </a>
                <?php } ?>
            </div>
        </div>
    </div>
</section>

<section class="mid-bar">
        <div class="container">
            <div class="row">
                <div class="col-md-3 ">
                    <a href="index.php"> 
                        <img class="logo mt-4 p-0" src="img/logo.png" alt="">
                    </a>
                </div>

                <div class="col-md-5 text-center d-flex pt-5">
                    <div class="col">
                        <input type="search" id="searchTerm" name="search" class="mt-5 form-control p-1 search-bar" placeholder="search any thing ...">
                    </div>
                    <div class="">        
                        <i type="submit" id="searchButton" class="btn mt-5 search-btn  text-light fa-solid fa-magnifying-glass"></i>
                    </div>
                </div>
               
                <div class="col-md-3 text-center mt-3 pt-5">
                </div>
            </div>
        </div>
    </section>
 <?php  
//     if (isset($_POST['search'])) {
//     $search = $_POST['search'];

//     $query = "SELECT * FROM products WHERE BLOG_NAME  LIKE '% %'";
//     $result = mysqli_query($conn, $query);
    
// }
?>


<section class="end-bar">
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="shop.php">Shop</a>
                </li><li class="nav-item">
                <a class="nav-link" href="contact.php">Contact</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="about.php">Help</a>
                </li>
            </ul>
            
            </div>
        </div>
    </nav>
</section>
