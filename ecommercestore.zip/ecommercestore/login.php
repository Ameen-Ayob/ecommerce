<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include 'includes/links.php';?>
    </head>
    <body>
        <?php include 'nav-bar.php'; ?>
            <div class="container">    
                <u><h3 class="text-center">LOG IN</h3></u>
                <form method="POST" class="login">
                    <div class="row d-flex">
                        <div class="col-md-5">
                            <input type="text" name="fname" placeholder="First name" class="form-control " required>
                        </div>
                        <div class="col-md-5">
                            <input type="text" name="lname" placeholder="Last Name" class="form-control" required>
                        </div>
                    </div>    
                    <div class="row d-flex">
                        <div class="col-md-5">
                            <input type="text" name="address" placeholder="Address" class="form-control my-3" required>
                        </div>
                        <div class="col-md-5">
                            <input type="text" name="appartment" placeholder="Appartment, suite etc (optional)" class="form-control my-3" required>
                        </div>
                    </div>
                    <div class="col-md-10">
                        <input type="text" name="city" placeholder="City" class="form-control mb-3" required>
                    </div>
                    <div class="col-md-10">
                        <input type="text" name="email" placeholder="E-mail" class="form-control mb-3" required>
                    </div>
                    <div class="col-md-10">
                        <input type="text" name="phone" placeholder="Phone No." class="form-control mb-3" required>                    
                    </div>
                    <div class="col-md-10">
                        <input type="text" name="poostalcode" placeholder="Postal code" class="form-control" required>
                    </div>
                    <button type="submit" class="btn form-btn my-3 px-4">Submit</button>
                </form>
            </div>

        <?php
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $fname = $_POST['fname'];
                $lname = $_POST['lname'];
                $address = $_POST['address'];
                $appartment = $_POST['appartment'];
                $city = $_POST['city'];
                $email = $_POST['email'];
                $phone = $_POST['phone'];
                $postalcode = $_POST['poostalcode'];
            
                if (empty($fname) || empty($lname) || empty($address) || empty($appartment) || empty($email) || empty($phone) || empty($postalcode) || empty($city)) {
                    echo "All fields are required.";
                } else {
                    $login = "INSERT INTO `user`( `first_name`, `last_name`, `address`, `appartment`, `city`, `email`, `phone`, `postal_code`) VALUES ('{$fname}', '{$lname}', '{$address}', '{$appartment}', '{$city}', '{$email}', '{$phone}', '{$postalcode}')";
                    $exeLogin = mysqli_query($conn, $login);            
                    if ($exeLogin === true) {
                        $user_id = $conn->insert_id;
                        $_SESSION['user'] = $user_id;
                        header("location:index.php");
                    } else {
                        echo "Error";
                    }
                }
            }
            
        ?>
        

        <?php include 'footer.php'; ?>
        <?php include 'includes/script.php'; ?>
    </body>
</html>