<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include 'includes/links.php'; ?>
    </head>
    <body>
        <?php include 'nav-bar.php'; ?>
        <section class="contact-form my-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="heading mt-4">
                            <u><h4>PRODUCTS</h4></u>
                        </div>
                        
                        <div class="row">
                            <?php 
                                $user_id = $_SESSION['user'];
                                $cart = "SELECT O.*, P.* FROM `order` AS O JOIN `product` AS P ON O.product_id = P.product_id WHERE O.user_id = '$user_id' AND O.status = 'cart'";
                                $exeCart = mysqli_query($conn, $cart);
                                if (mysqli_num_rows($exeCart) > 0) {
                                    while ($resExaCart = mysqli_fetch_array($exeCart)) {
                            ?>
                                    <div class="col-md-6">
                                        <div class="card product-card">
                                            <img src="./Admin/<?php echo $resExaCart['product_image']; ?>" class="card-img-top" alt="Product Image" style="height:100%;width:100%;">
                                            <div class="card-body">
                                                <a href="product.php?id=<?php echo $resExaCart['product_id']; ?>" class="text-decoration-none text-dark d-flex justify-content-between">
                                                    <h5 class="card-title" style="font-size:14px; font-weight:600;"><?php echo $resExaCart['product_title']; ?></h5><?php echo 'X'.$resExaCart['quantity']; ?>
                                                </a>
                                                <p class="card-text m-0" style="font-size:14px;">Article: <?php echo $resExaCart['product_code']; ?></p>
                                                <p class="card-text m-0" style="font-size:14px;">Price: PKR.<?php echo $resExaCart['product_price'] * $resExaCart['quantity']; ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                            <?php   }
                                }
                            ?>
                        </div>
                        <form method="POST">
                            <u><h4 class="mt-3">CONTACT</h4></u>
                            <?php
                                $userDetail = "SELECT * FROM `user` WHERE `user_id` = '{$_SESSION['user']}'";
                                $userDetailQuery = mysqli_query($conn, $userDetail);
                                $userDetails = mysqli_fetch_array($userDetailQuery);
                            ?>
                            <div class="row d-flex">
                                <div class="col-md-5">
                                    <input type="text" name="fname" placeholder="First name" class="form-control" value="<?php echo $userDetails['first_name']; ?>" disabled >
                                </div>
                                <div class="col-md-5">
                                    <input type="text" name="lname" placeholder="Last Name" class="form-control" value="<?php echo $userDetails['last_name']; ?>" disabled>
                                </div>
                            </div>    
                            <div class="row d-flex">
                                <div class="col-md-5">
                                    <input type="text" name="address" placeholder="Address" class="form-control my-3" value="<?php echo $userDetails['address']; ?>" disabled>
                                </div>
                                <div class="col-md-5">
                                    <input type="text" name="appartment" placeholder="Appartment, suite etc (optional)" class="form-control my-3" value="<?php echo $userDetails['appartment']; ?>" disabled>
                                </div>
                            </div>
                            <div class="col-md-10">
                                <input type="text" name="city" placeholder="City" class="form-control mb-3" value="<?php echo $userDetails['city']; ?>" disabled>
                            </div>
                            <div class="col-md-10">
                                <input type="text" name="email" placeholder="E-mail" class="form-control mb-3" value="<?php echo $userDetails['email']; ?>" disabled>
                            </div>
                            <div class="col-md-10">
                                <input type="text" name="phone" placeholder="Phone No." class="form-control mb-3" value="<?php echo $userDetails['phone']; ?>" disabled>                    
                            </div>
                            <div class="col-md-10">
                                <input type="text" name="poostalcode" placeholder="Postal code" class="form-control" value="<?php echo $userDetails['postal_code']; ?>" disabled>
                            </div>
                            <button type="submit" name="submit" value="1" class="btn form-btn my-3 px-4">Submit</button>
                        </form>

                        <?php
                            if(isset($_POST['submit'])){
                                $updateCart = "UPDATE `order` SET `status` = 'orderPending' WHERE `user_id` = '{$_SESSION['user']}'";
                                $updateCartQuery = mysqli_query($conn, $updateCart);
                                if($updateCartQuery){
                                    header('location: index.php');
                                }
                            }
                        ?>

                    </div>
                </div>
            </div>
        </section>

        <?php include 'footer.php'; ?>
        <?php include 'includes/script.php'; ?>

    </body>
</html>
