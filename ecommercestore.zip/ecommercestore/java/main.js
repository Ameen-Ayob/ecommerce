$(document).on('click', '#cartBtn', function(){

    var productId = $(this).data('id');
    $.ajax({
        url: 'login_check.php', 
        method: 'POST',
        success: function(response) {
            if (response.trim() === 'logged_in') {
                $.ajax({
                    url: 'add_to_cart.php',
                    method: 'POST',
                    data: { product_id: productId, quantity: 1 },
                    success: function(response) {
                        alert(response);
                        // alert('Product added to cart!');
                    }
                });
            } else {
                window.location.href = 'login.php';
            }
        }
    });

});