<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include 'includes/links.php'?>
    </head>
    <body>
        <?php include 'nav-bar.php'?>

        <div class="container">
            <div class="row">
                <?php
                    if (isset($_GET['id'])) {
                        $id = $_GET['id'];
                        $blog = "SELECT * FROM `product` WHERE `product_id` = '{$id}'";
                        $exeblog = mysqli_query($conn, $blog);
        
            
                        if ($exeResult = mysqli_fetch_array($exeblog)) { 
                ?>
                <div class="col-md-12">
                    <img Style="height:20%; height:15%;" src="./Admin/<?php echo htmlspecialchars($exeResult['product_image']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($exeResult['product_title']); ?></h5>
                            <p>
                                Price : 
                            <?php echo htmlspecialchars($exeResult['product_price']); ?> <br>
                            </p>
                        </div>
                        <div class="buttons">
                            <a class="text-decoration-none text-dark" href="cart.php">
                                <button type="button" class="btn">Add to Cart</button>
                            </a>
                        </div>
                <?php } } ?>
                </div>
            </div>
        </div>
            
      
        <?php include 'footer.php'?>
        <?php include 'includes/script.php'?>
    </body>
</html>